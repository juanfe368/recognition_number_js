January 13, 2015

	* Major update to Ocrad.js, based on Ocrad 0.24
	* New Asynchronous API automatically handles creation of web workers
	* New recognition options
		* scale — upscale or downscale the input image by an integer factor
		* filters — restrict recognition to letters, or numbers
		* transform — apply rotation or mirroring to image
	* Directly recognize text from image or video elements
	* Simple API for recognizing determining the location of text blocks, lines or individual characters
	* Lazy initialization — it doesn't initialize emscripten until run for the first time

May 6, 2014
	
	* NodeJS module

January 1, 2014

	* First Version of Ocrad.js, based on 0.23-prelease of Ocrad