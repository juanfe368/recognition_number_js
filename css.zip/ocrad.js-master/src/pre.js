var OCRAD = (function(){
function createOcradInstance(){

